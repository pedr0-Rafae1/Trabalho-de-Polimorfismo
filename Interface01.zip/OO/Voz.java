package OO;

public interface Voz {
	
	public void Fala();

}
