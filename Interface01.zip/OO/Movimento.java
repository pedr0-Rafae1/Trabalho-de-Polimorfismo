package OO;

public interface Movimento {

	public void Andar();
}
