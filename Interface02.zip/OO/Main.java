package OO;

public class Main {

	public static void main (String[] args ) {
	
		Canguru c1 = new Canguru();
		c1.Caminhar();
		c1.Comer();
		c1.Respirar();
		c1.Saltar();
	}
}
