package OO;

public interface Saltador {

	public void Saltar();
}
