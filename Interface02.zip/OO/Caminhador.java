package OO;

public interface Caminhador {

	public void Caminhar();
}
