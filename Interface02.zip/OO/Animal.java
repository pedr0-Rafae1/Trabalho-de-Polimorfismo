package OO;

abstract class Animal {
	
	abstract void Comer();
	
	public void Respirar() {
		System.out.println("o canguru esta respirando");
	}
	
}
